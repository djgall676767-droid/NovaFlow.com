NOVAFLOW.COM WEBSITE

The website branding is set to NovaFlow.com.

Before publishing:
1. Replace YOUR-EMAIL@example.com in index.html with your real email.
2. NovaFlow.com shown in the website does not itself register the domain.
3. To use the actual NovaFlow.com address, you must register the domain if it is available and connect it to your hosting.
